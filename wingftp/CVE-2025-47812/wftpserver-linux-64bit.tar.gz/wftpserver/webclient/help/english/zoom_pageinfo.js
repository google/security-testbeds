pageinfo = [[0,0,0,0,null],
	[0,0,0,0,null],
	[0,0,0,0,null],
	[0,0,0,0,null]];
pagedata = [ ["requirements.htm","Using Web Client &#62; Quick Guide","Quick Guide",""],
["uoeoeia.htm","Using Web Client &#62; Overview","Overview",""],
["using_picture_viewer.htm","Using the web client &#62; Using Picture Viewer","Using Picture Viewer",""],
["using_text_editor.htm","Using Web Client &#62; Using Text Editor","Using Text Editor",""]];
